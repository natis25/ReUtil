package com.paginainicio.PaginaInicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaginaInicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
