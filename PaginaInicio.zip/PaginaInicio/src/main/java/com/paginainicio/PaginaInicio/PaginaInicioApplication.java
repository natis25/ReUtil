package com.paginainicio.PaginaInicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaginaInicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaginaInicioApplication.class, args);
	}

}
